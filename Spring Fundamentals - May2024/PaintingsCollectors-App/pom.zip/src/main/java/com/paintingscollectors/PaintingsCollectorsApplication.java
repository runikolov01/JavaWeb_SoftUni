package com.paintingscollectors;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaintingsCollectorsApplication {

    public static void main(String[] args) {
        SpringApplication.run(PaintingsCollectorsApplication.class, args);
    }
}
